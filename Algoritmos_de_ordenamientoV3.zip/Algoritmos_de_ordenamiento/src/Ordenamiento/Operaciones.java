package Ordenamiento;

import java.util.Scanner;

public class Operaciones extends Algoritmos {
     
    public Operaciones(int tipo, int caso) {
        super(tipo, caso);
    }
    
    public void sumar(){
        int filas, columnas;
        Scanner in=new Scanner(System.in);
        System.out.println("Digite la cantidad de filas que desea:");
        filas=in.nextInt();
        System.out.println("Digite la cantidad de columnas que desea:");
        columnas=in.nextInt();
        double [][] matriz1=new double[filas][columnas]; 
        System.out.println("Digite los numero a agregar a la matriz 1");
        for(int i=0; i<filas; i++){//matriz 1
            for(int j=0; j<columnas; j++){
                matriz1[i][j]=in.nextDouble();
            }
        }
        double [][] matriz2=new double[filas][columnas]; 
        System.out.println("Digite los numero a agregar a la matriz 2");
        for(int i=0; i<filas; i++){//matriz 2
            for(int j=0; j<columnas; j++){
                matriz2[i][j]=in.nextDouble();
            }
        }
        double [][] matriz3=new double[filas][columnas]; 
        System.out.println("Resultado de la suma: ");
        for(int i=0; i<filas; i++){//Resultado de la suma
            for(int j=0; j<columnas; j++){
            matriz3[i][j]=matriz1[i][j]+matriz2[i][j];
            System.out.print(matriz3[i][j]+"\t");
            }
            System.out.println();
        }
        System.out.println();
    }
    
    public void multiplicacion(){
       int filas, columnas, filas1, columnas1;
       Scanner in= new Scanner(System.in);
       System.out.println("Digite la cantidad de filas que desea de la matriz 1:");
       filas=in.nextInt();
       System.out.println("Digite la cantidad de columnas que desea de la matriz 1:");
       columnas=in.nextInt();
       System.out.println("Digite la cantidad de filas que desea de la matriz 2:");
       filas1=in.nextInt();
       if(columnas!=filas1){//Comprobacion de validez
         System.out.println("Producto de matriz erroneo");
         
       }
        System.out.println("Digite la cantidad de columnas que desea de la matriz 2:");
        columnas1=in.nextInt();
        System.out.println();
        double [][] matriz1=new double[filas][columnas];
        double [][] matriz2=new double[filas1][columnas1];
        System.out.println("Digite todos los numeros de la matriz 1:");
        for(int i=0; i<filas; i++){//matriz 1
            for(int j=0; j<columnas; j++){
                matriz1[i][j]=in.nextDouble();
            }
        }
        System.out.println("Digite todos los numeros de la matriz 2:");
        for(int i=0; i<filas1; i++){//matriz 2
            for(int j=0; j<columnas1; j++){
                matriz2[i][j]=in.nextDouble();
            }
        }
        double [][] matriz3= new double [filas][columnas1];
        for(int i=0; i<filas; i++){//Resultado del producto
            for(int j=0; j<columnas1; j++){
                for(int k=0; k<columnas; k++){
                    matriz3[i][j]+=matriz1[i][k]*matriz2[k][j];
                }
            }
        }
        System.out.println("Resultado del producto: ");
        for(int i=0; i<filas; i++){
            for(int j=0; j<columnas1; j++){
                System.out.print(matriz3[i][j]+"\t");
                }
                System.out.println();
        }
        System.out.println();
    }
    
    public void multiescalar(){
        int filas, columnas;
        double escalar;
        Scanner in= new Scanner(System.in);       
        System.out.println("Digite la cantidad de filas que desea:");
        filas=in.nextInt();
        System.out.println("Digite la cantidad de columnas que desea:");
        columnas=in.nextInt();
        System.out.println("Digite el escalar por el que quiere multiplicar:");
        escalar=in.nextDouble();
        double [][] matriz1 = new double[filas][columnas];
        System.out.println();
        System.out.println("Digite los numero a agregar a la matriz 1");
        for(int i=0; i<filas; i++){//matriz 
            for(int j=0; j<columnas; j++){
                matriz1[i][j]=in.nextDouble();
            }
        }
        double [][] matriz3 = new double[filas][columnas];
        for(int i=0; i<filas; i++){//Resultado
            for(int j=0; j<columnas; j++){
                matriz3[i][j]=matriz1[i][j]*escalar;
            }
        }
        System.out.println();
        System.out.println("Resultado de la multiplicacion por el escalar: ");
        for(int i=0; i<filas; i++){//Resultado de la multiplicacion por el escalar
            for(int j=0; j<columnas; j++){
            System.out.print(matriz3[i][j]+"\t");
            }
            System.out.println();
        }
        System.out.println();
    }
    
    public void transpuesta(){
        int filas, columnas;
        Scanner in= new Scanner(System.in);
        System.out.println("Digite la cantidad de filas que desea:");
        filas=in.nextInt();
        System.out.println("Digite la cantidad de columnas que desea:");
        columnas=in.nextInt();
        double [][] matriz1= new double[filas][columnas];
        System.out.println("Digite los numero a agregar a la matriz 1");
        for(int i=0; i<filas; i++){//matriz 1
            for(int j=0; j<columnas; j++){
                matriz1[i][j]=in.nextDouble();
            }
        }
        double [][] matriz3= new double[filas][columnas];
        for(int i=0; i<filas; i++){//matriz 1
            for(int j=0; j<columnas; j++){
                matriz3[j][i]=matriz1[i][j];
            }
        }
        System.out.println();
        System.out.println("Resultado de la matriz transpuesta");
        for(int i=0; i<filas; i++){//Resultado de la transpuesta
            for(int j=0; j<columnas; j++){
                System.out.print(matriz3[i][j]+"\t");
            }
            System.out.println();
        }
        System.out.println();
    }
}
