
package Ordenamiento;

import static java.lang.Math.random;

public class Orden extends Algoritmos {
    long time[];
    int cont;

    public Orden(int tipo, int caso) {
        super(tipo, caso);
        this.cont = 0;
        this.time = new long[20];
    }
    
    public void burbuja(){
        long inicio=System.nanoTime();
        int cant=100;
        boolean ordenada;
        while(cant<10000){
        double vector1[]= new double[cant];
        for(int i=0; i<cant; i++){
            vector1[i]=random()*cant;//Llenado de vector
        }
        for(int i=0; i<cant-1; i++){//Metodo
            ordenada=false;
            for(int j=0; j<cant-i-1; j++){
              if(vector1[j]>vector1[j+1]){
                double temporal=vector1[j];
                vector1[j]=vector1[j+1];
                vector1[j+1]=temporal;
                ordenada=true;
            }  
            }
            if(!ordenada){
                break;
            }
        }
        long fin=System.nanoTime();
        long tot=fin-inicio;//tiempo total
        time[cont]=tot;
        cont++;
        System.out.println("Array ordenado #"+cont);
        for(int i=0; i<cant; i++){
            System.out.print(vector1[i]+ " ");
        }
        System.out.println("");
        if(cant==500||cant==5000){
            cant*=2;
        }else{cant*=5;}
        }
        System.out.println();
        System.out.println("Metodo Burbuja: ");
        tiempo();
    }
    
    public void insercion(){
        long inicio=System.nanoTime();
        int cant=100;
        while(cant<10000){
            double vector1[]= new double[cant];
            for(int i=0; i<cant; i++){
                vector1[i]=random()*cant;
            }
            for(int i=1; i<cant; i++){
                double camb=vector1[i];
                int temp=i-1;
                while(temp>=0 && vector1[temp]>camb){
                    vector1[temp+1]=vector1[temp];
                    temp-=1;
                }
                vector1[temp+1]=camb;
            }
            long fin=System.nanoTime();
            long tot=fin-inicio;
            time[cont]=tot;
            cont++;
            System.out.println("Array ordenado #"+cont);
            for(int i=0; i<cant; i++){
                System.out.print(vector1[i]+ " ");
            }
            System.out.println("");
            if(cant==500||cant==5000){
                cant*=2;
            }else{cant*=5;}
        }
        System.out.println();
        System.out.println("Metodo insercion: ");
        tiempo();
    }
    
    public void selec(){
        long inicio=System.nanoTime();
        int cant=100;
        while(cant<10000){
            double vector1[]= new double[cant];
            for(int i=0; i<cant; i++){
                vector1[i]=random()*cant;
            }
            for(int i=0; i<cant; i++){
                int min=i;
                for(int j=i+1; j<cant; j++){
                    if(vector1[j]<vector1[min]){
                        min=j;
                    }
                }
                double temp = vector1[min];
                vector1[min]=vector1[i];
                vector1[i]=temp;
            }
            long fin=System.nanoTime();
            long tot=fin-inicio;
            time[cont]=tot;
            cont++;
            System.out.println("Array ordenado #"+cont);
            for(int i=0; i<cant; i++){
                System.out.print(vector1[i]+ " ");
            }
            System.out.println("");
            if(cant==500||cant==5000){
                cant*=2;
            }else{cant*=5;}
        }
        System.out.println();
        System.out.println("Metodo seleccion: ");
        tiempo();
    }
        
    public void mergeSort(double arr[], int l, int r) {
    if (l < r) {
        int m = (l + r) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}

public void merge(double arr[], int l, int m, int r) {
    int n1 = m - l + 1;
    int n2 = r - m;

    double L[] = new double[n1];
    double R[] = new double[n2];

    for (int i = 0; i < n1; ++i)
        L[i] = arr[l + i];
    for (int j = 0; j < n2; ++j)
        R[j] = arr[m + 1 + j];

    int i = 0, j = 0;
    int k = l;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

public void merge() {
    long inicio = System.nanoTime();
    int cant = 100;
    while (cant < 10000) {
        double vector1[] = new double[cant];
        for (int i = 0; i < cant; i++) {
            vector1[i] = random() * cant;
        }

        mergeSort(vector1, 0, cant - 1);

        long fin = System.nanoTime();
        long tot = fin - inicio;
        time[cont] = tot;
        cont++;
        System.out.println("Array ordenado #" + cont);
        for (int i = 0; i < cant; i++) {
            System.out.print(vector1[i] + " ");
        }
        System.out.println("");
        if (cant == 500 || cant == 5000) {
            cant *= 2;
        } else {
            cant *= 5;
        }
    }
    System.out.println();
    System.out.println("Metodo merge");
    tiempo();
    }
    
    public void todos(){
        System.out.println("");
        System.out.println("Burbuja: ");
        burbuja();
        System.out.println("Insercion: ");
        insercion();
        System.out.println("Seleccion: ");
        selec();
        System.out.println("Merge.sort: ");
        merge();
    }
    void tiempo(){
        for(int i=0; i<cont; i++){
            System.out.println(time[i]+"ns");
        }
        cont=0;
        System.out.println("");
    }
}