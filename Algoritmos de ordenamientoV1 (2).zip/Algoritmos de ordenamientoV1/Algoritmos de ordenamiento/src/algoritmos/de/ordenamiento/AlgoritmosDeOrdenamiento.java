
package algoritmos.de.ordenamiento;

import java.util.Scanner;

public class AlgoritmosDeOrdenamiento {
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        //Declaracion de variables y arrays
       double [][] matriz1= new double[150][150];
       double [][] matriz2= new double[150][150];
       double [][] matriz3= new double[150][150];
       double escalar;
       Scanner in=new Scanner(System.in);
       int tipo, op, or, filas, columnas, filas1, columnas1;
       String cont="";
       //Menu principal
       do{
        System.out.println("->Algoritmos de ordenamiento<-");
        System.out.println("Seleccione el tipo de operacion:");
        System.out.println("1) Operaciones matematicas con matrices");
        System.out.println("2) Ordenamiento de numeros segun eleccion");
        System.out.println("3) Salir");
        tipo=in.nextInt();
        switch(tipo){
            case 1->{//Operaciones matematicas
                System.out.println("");
                System.out.println("Seleccione la operacion deseada:");
                System.out.println("1) Suma de matrices");
                System.out.println("2) Producto de matrices");
                System.out.println("3) Producto de un escalar por una matriz");
                System.out.println("4) Transpuesta de una matriz");
                op=in.nextInt();
                System.out.println();
                switch(op){
                    case 1->{//Suma
                        System.out.println("Digite la cantidad de filas que desea:");
                        filas=in.nextInt();
                        System.out.println("Digite la cantidad de columnas que desea:");
                        columnas=in.nextInt();
                        System.out.println("Digite los numero a agregar a la matriz 1");
                        for(int i=0; i<filas; i++){//matriz 1
                            for(int j=0; j<columnas; j++){
                                matriz1[i][j]=in.nextDouble();
                            }
                        }
                        System.out.println("Digite los numero a agregar a la matriz 2");
                        for(int i=0; i<filas; i++){//matriz 2
                            for(int j=0; j<columnas; j++){
                                matriz2[i][j]=in.nextDouble();
                            }
                        }
                        System.out.println("Resultado de la suma: ");
                        for(int i=0; i<filas; i++){//Resultado de la suma
                            for(int j=0; j<columnas; j++){
                                matriz3[i][j]=matriz1[i][j]+matriz2[i][j];
                                System.out.print(matriz3[i][j]+"\t");
                            }
                            System.out.println();
                        }
                         System.out.println();
                         break;
                    }
                    case 2 ->{//Multiplicacion
                        System.out.println("Digite la cantidad de filas que desea de la matriz 1:");
                        filas=in.nextInt();
                        System.out.println("Digite la cantidad de columnas que desea de la matriz 1:");
                        columnas=in.nextInt();
                        System.out.println("Digite la cantidad de filas que desea de la matriz 2:");
                        filas1=in.nextInt();
                        if(columnas!=filas1){//Comprobacion de validez
                            System.out.println("Producto de matriz erroneo");
                            break;
                        }
                        System.out.println("Digite la cantidad de columnas que desea de la matriz 2:");
                        columnas1=in.nextInt();
                        System.out.println();
                        System.out.println("Digite todos los numeros de la matriz 1:");
                        for(int i=0; i<filas; i++){//matriz 1
                            for(int j=0; j<columnas; j++){
                                matriz1[i][j]=in.nextDouble();
                            }
                        }
                        System.out.println("Digite todos los numeros de la matriz 2:");
                        for(int i=0; i<filas1; i++){//matriz 2
                            for(int j=0; j<columnas1; j++){
                                matriz2[i][j]=in.nextDouble();
                            }
                        }
                        for(int i=0; i<filas; i++){//Resultado del producto
                            for(int j=0; j<columnas1; j++){
                                for(int k=0; k<columnas; k++){
                                    matriz3[i][j]+=matriz1[i][k]*matriz2[k][j];
                                }
                            }
                        }
                        System.out.println("Resultado del producto: ");
                        for(int i=0; i<filas; i++){
                            for(int j=0; j<columnas1; j++){
                                System.out.print(matriz3[i][j]+"\t");
                            }
                            System.out.println();
                        }
                        System.out.println();
                        break;
                    }
                    case 3 ->{
                        System.out.println("Digite la cantidad de filas que desea:");
                        filas=in.nextInt();
                        System.out.println("Digite la cantidad de columnas que desea:");
                        columnas=in.nextInt();
                        System.out.println("Digite el escalar por el que quiere multiplicar:");
                        escalar=in.nextDouble();
                        System.out.println();
                        System.out.println("Digite los numero a agregar a la matriz 1");
                        for(int i=0; i<filas; i++){//matriz 
                            for(int j=0; j<columnas; j++){
                                matriz1[i][j]=in.nextDouble();
                            }
                        }
                        for(int i=0; i<filas; i++){//Resultado
                            for(int j=0; j<columnas; j++){
                                matriz3[i][j]=matriz1[i][j]*escalar;
                            }
                        }
                        System.out.println();
                        System.out.println("Resultado de la multiplicacion por el escalar: ");
                        for(int i=0; i<filas; i++){//Resultado de la multiplicacion por el escalar
                            for(int j=0; j<columnas; j++){
                                System.out.print(matriz3[i][j]+"\t");
                            }
                            System.out.println();
                        }
                         System.out.println();
                         break;
                    }
                    case 4->  {
                        System.out.println("Digite la cantidad de filas que desea:");
                        filas=in.nextInt();
                        System.out.println("Digite la cantidad de columnas que desea:");
                        columnas=in.nextInt();
                        System.out.println("Digite los numero a agregar a la matriz 1");
                        for(int i=0; i<filas; i++){//matriz 1
                            for(int j=0; j<columnas; j++){
                                matriz1[i][j]=in.nextDouble();
                            }
                        }
                        for(int i=0; i<filas; i++){//matriz 1
                            for(int j=0; j<columnas; j++){
                                matriz3[j][i]=matriz1[i][j];
                            }
                        }
                        System.out.println();
                        System.out.println("Resultado de la matriz transpuesta");
                        for(int i=0; i<filas; i++){//Resultado de la transpuesta
                            for(int j=0; j<columnas; j++){
                                System.out.print(matriz3[i][j]+"\t");
                            }
                            System.out.println();
                        }
                         System.out.println();
                         break;
                    }
                    default-> System.out.println("Operacion no existente");
                }
                break;
            }
            case 2->{
                System.out.println();
                System.out.println("Ordenamiento de arrays:");
                System.out.println("Seleccione una opcion a ordenar:");
                System.out.println("100-500-1000-5000-10000");
                or=in.nextInt();
                double [] ord=new double[or];
                for(int i=0;i<or;i++){
                   ord[i]=Math.random()*5000;
                }
                System.out.println();
                System.out.println("->Tabla Comparativa<-");
                System.out.println("");
            }
            case 3->{
                cont="Salir";
                break;
            }
            default-> System.out.println("Tipo no existente...");
       }
       }
       while("".equals(cont));
    }
}