package Ordenamiento;

import java.util.Scanner;

public class Main {
   public static void main(String[] args){
       int tipo, caso;
       String seguir="";
       Scanner in= new Scanner(System.in);
       OUTER:
       do {
           System.out.println("->Algoritmos de ordenamiento");
           System.out.println("Seleccione el tipo de operacion:");
           System.out.println("1) Operaciones matematicas con matrices");
           System.out.println("2) Ordenamiento de numeros segun eleccion");
           System.out.println("3) Salir");
           tipo=in.nextInt();
           switch (tipo) {
               case 1 ->{
                       System.out.println("");
                       System.out.println("Seleccione la operacion deseada:");
                       System.out.println("1) Suma de matrices");
                       System.out.println("2) Producto de matrices");
                       System.out.println("3) Producto de un escalar por una matriz");
                       System.out.println("4) Transpuesta de una matriz");
                       caso=in.nextInt();
                       Algoritmos sel=new Algoritmos(tipo, caso);
                       sel.seleccionar();
                       System.out.println();
                   }
               case 2 ->{
                        System.out.println("");
                        System.out.println("Seleccione la operacion deseada:");
                        System.out.println("1)Burbuja");
                        System.out.println("2)Insercion");
                        System.out.println("3)Seleccion");
                        System.out.println("4)Merge-sort");
                        System.out.println("5)Todos");
                        System.out.println("6)Salir");
                        caso=in.nextInt();
                        Algoritmos sel=new Algoritmos(tipo, caso);
                        sel.seleccionar();
                        break;
                   }
               case 3 -> {
                   seguir="n";
                   break;
               }
               default -> {
                   System.out.println("Entrada no valida...");
                   break;
               }
           }
       } while ("".equals(seguir));
   }
}
