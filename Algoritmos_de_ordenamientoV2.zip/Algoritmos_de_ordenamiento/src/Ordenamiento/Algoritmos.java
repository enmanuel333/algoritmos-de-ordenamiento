package Ordenamiento;

public class Algoritmos {
    private int tipo;
    private int caso;

    public Algoritmos(int tipo, int caso){
        this.tipo=tipo;
        this.caso=caso;
    }

    public int getTipo() {
        return tipo;
    }

    public int getCaso() {
        return caso;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public void setCaso(int caso) {
        this.caso = caso;
    }

    public void seleccionar(){
        Operaciones op=new Operaciones(getTipo(), getCaso());
        Orden or=new Orden(getTipo(), getCaso());
        if(getTipo()==1){
            switch (getCaso()) {
                case 1 -> op.sumar();
                case 2 -> op.multiplicacion();
                case 3 -> op.multiescalar();
                case 4 -> op.transpuesta();
            }
        }else if(getTipo()==2){
            switch (getCaso()) {
                case 1-> or.burbuja();
                case 2-> or.insercion();
                case 3-> or.selec();
                case 4-> or.merge();
            }
            
        }  
    }
}